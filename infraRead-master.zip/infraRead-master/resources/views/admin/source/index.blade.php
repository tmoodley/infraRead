@extends('admin.layout')

@section('content')

<livewire:source-list></livewire:source-list>

@stop