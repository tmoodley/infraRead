    <div class="flex justify-between items-start">
      <a href="{{$edit}}" class="w-full">
      <div class="hover:bg-gray-50 w-full p-3 cursor-pointer rounded-md hover:shadow-sm">
        <div class="text-primary font-semibold text-xl tracking-wider">{{$title}}</div>
        <div class="text-gray-700">{{$description}}</div>
        <div class="text-gray-400">{{$category}}</div>
      </div>
      </a>
      {{-- <div class="ml-4 text-gray-200 px-4 py-1 border rounded hover:text-white hover:bg-primary hover:border-none">
        <a href="{{$edit}}">edit</a>
      </div> --}}
    </div>
