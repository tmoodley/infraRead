<?php

namespace App\Plugins;

interface PluginInterface{
    public function handle();
}